package main

const esbuildVersion = "0.25.12"
