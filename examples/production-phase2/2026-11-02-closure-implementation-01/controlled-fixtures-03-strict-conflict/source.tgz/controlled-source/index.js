// inert controlled fixture, never executed
