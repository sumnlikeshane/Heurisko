// authored inert baseline
export const value = 1;
